package rio33;


public class luas_segitiga {
    public static void main(String[] args) {
        int a = 25;
        int t = 75;
        double Luas = 0.5 * a * t;
        
        System.out.println ("alas = " + (a));
        System.out.println ("tinggi = " + (t));
        System.out.println ("Luas Segitiga = " + (Luas));
    }
}
