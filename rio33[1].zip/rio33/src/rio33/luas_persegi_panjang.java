package rio33;


public class luas_persegi_panjang {
    public static void main(String[] args){
        int p = 35;
        int l = 25;
        int t = 30;
        double luas = p * l * t;
        
        System.out.println ("panjang = " + (p));
        System.out.println ("lebar = " + (l));
        System.out.println ("tinggi = " + (t));
        System.out.println ("luas persegi panjang = " + (luas));
    }
    
}
